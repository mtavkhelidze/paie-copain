import { Customer, Transaction } from "./types";
import * as path from "path";

export const PACKAGE_NAME = "paie-copain";

export const SERVER_PORT = process.env.PORT || 3000;
export const SERVER_API_ROOT = process.env.PORT || "/api";

export const DB_INITIAL_CUSTOMER: Customer = {
    id: 1,
    email: "misha.tavkhelidze@gmail.com",
    name: "Misha",
    balance: 100
};

export const DB_INITIAL_DEBIT_TRANSACTION: Transaction = {
    id: 1,
    created: Date.now(),
    nostro: "misha.tavkhelidze@gmail.com",
    vostro: "user@domain.tld",
    amount: 37
};

export const DB_INITIAL_CREDIT_TRANSACTION: Transaction = {
    id: 2,
    created: Date.now(),
    nostro: "user@domain.tld",
    vostro: "misha.tavkhelidze@gmail.com",
    amount: 13
};

export const DB_DSN = process.env.DSN || `${PACKAGE_NAME}.sqlite3`;
export const GRAPHQL_SCHEAM_FILE = path.join(__dirname, "./schema.graphqls");
